package TestNgTest;

import org.openqa.selenium.By;

public class TestData {
	
	By btnOurproducts= By.xpath("//a[text()='Our Products']");

}
