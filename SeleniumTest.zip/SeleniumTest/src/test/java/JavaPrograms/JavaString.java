package JavaPrograms;

public class JavaString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
