package SeleniumProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirtstTest {
	WebDriver driver;

	
	//ChromeOptions chromeOptions = new ChromeOptions();
	//chromeOptions.addArguments("--remote-allow-origins=*"); 
	
	

}
